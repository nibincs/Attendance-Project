// Main JS logic for Attendance Tracker
// Modular functions for each role and feature

// Utility: Show login/signup forms
function showLogin(role) {
    // ...existing code...
    // Render login/signup form based on role
}

// Utility: Logout
function logout() {
    auth.signOut().then(() => {
        window.location.href = 'index.html';
    });
}

// Geolocation: Get current position
function getCurrentLocation(callback) {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            position => callback(position.coords),
            err => alert('Geolocation error: ' + err.message)
        );
    } else {
        alert('Geolocation not supported');
    }
}

// Geofence: Check if within 200m
function isWithinGeofence(userLat, userLng, fenceLat, fenceLng) {
    const R = 6371000; // meters
    const dLat = (fenceLat - userLat) * Math.PI / 180;
    const dLng = (fenceLng - userLng) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
        Math.cos(userLat * Math.PI / 180) * Math.cos(fenceLat * Math.PI / 180) *
        Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distance = R * c;
    return distance <= 200;
}

// Admin: Manage Advisors, Students, Attendance
function loadAdminDashboard() {
    // ...existing code...
    // Fetch and render advisors, students, attendance data
}

// Advisor: Set geofence, configure breaks, handle requests
function setGeofence() {
    getCurrentLocation(coords => {
        // Save geofence to Firestore
        // ...existing code...
    });
}
function saveBreaks(breaks) {
    // Save breaks config to Firestore
    // ...existing code...
}
function loadAdvisorDashboard() {
    // ...existing code...
    // Fetch geofence, breaks, requests
}
function handleEmergencyRequest(requestId, approve) {
    // Approve/reject request in Firestore
    // ...existing code...
}

// Student: Check-in/out, manual override, history, summary
function checkIn() {
    getCurrentLocation(coords => {
        // Fetch geofence from Firestore
        // If within 200m, log check-in
        // ...existing code...
    });
}
function checkOut() {
    getCurrentLocation(coords => {
        // Fetch geofence from Firestore
        // If within 200m, log check-out
        // ...existing code...
    });
}
function submitOverrideRequest(reason, timeWindow) {
    // Submit manual override request to Firestore
    // ...existing code...
}
function loadStudentDashboard() {
    // ...existing code...
    // Fetch attendance history, summary, notifications
}

// Notifications: Real-time listeners
function setupNotifications(role) {
    // Listen for relevant Firestore changes
    // ...existing code...
}

// Reminder: Auto check-out notification
function setupAutoCheckoutReminder() {
    // ...existing code...
}

// Firebase Auth: Sign-up/Login for all roles
function signup(role, data) {
    // ...existing code...
    // Create user in Firebase Auth and Firestore
}
function login(role, data) {
    // ...existing code...
    // Authenticate user and redirect to dashboard
}

// On page load, route to correct dashboard
window.onload = function() {
    // ...existing code...
    // Check auth state, route to dashboard
};